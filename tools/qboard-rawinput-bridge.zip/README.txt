Q-board Raw Input Bridge / Q-board 外接键盘桥接器

Windows 使用方法：
1. 完整解压 qboard-rawinput-bridge.zip。
2. 双击 start-qboard-bridge.cmd。
3. 如果 Windows 首次显示安全提示，请确认运行。
4. 窗口显示 Listening 后，回到 Q-board 网页。
5. 在“键盘设置”标题中点一次“+”，再按一下要绑定的外接键盘；每增加一把实体键盘重复一次。

如果浏览器询问是否允许访问本地网络，请选择允许。

不要直接在压缩包中运行启动器。启动器和
qboard-rawinput-bridge.ps1 必须位于同一文件夹。

English:
1. Extract the entire qboard-rawinput-bridge.zip archive.
2. Double-click start-qboard-bridge.cmd.
3. Confirm the first-run Windows security prompt if it appears.
4. Wait until the window shows Listening, then return to Q-board.
5. Click + once in the Keyboard settings title, then press one key on the physical keyboard to bind it. Repeat for each keyboard.

Allow local-network access if the browser asks for permission.

Do not run the launcher from inside the ZIP. The launcher and
qboard-rawinput-bridge.ps1 must remain in the same folder.
